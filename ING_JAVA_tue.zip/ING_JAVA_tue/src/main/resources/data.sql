
/* 
    delete from users;
	delete from ingtradeapp.stock;
	delete from ingtradeapp.orders;
	insert into ingtradeapp.users(id,name,password,role) values(1,'test','test','ROLE_USER');
	insert into ingtradeapp.stock values(1,'HCL');
	insert into ingtradeapp.stock(id,name) values(2,'ING');
    insert into Orders(id,fees,stock_name,stock_price,trade_time,volume,user_name) values(1,31,'ING',23,'2018-05-04',31,'test');
    insert into Orders(id,fees,stock_name,stock_price,trade_time,volume,user_name) values(2,31,'HCL',53,'2018-06-07',53,'test');
*/